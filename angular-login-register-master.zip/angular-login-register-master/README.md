# Myapp

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 13.2.3.

## Install
Run `npm install` for installing packages for the project

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

