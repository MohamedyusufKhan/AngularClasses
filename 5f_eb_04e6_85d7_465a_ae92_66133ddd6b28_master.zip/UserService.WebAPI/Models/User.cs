﻿using System.ComponentModel.DataAnnotations;

namespace UserService.WebAPI.Models
{
    public class User
    {
        public string Name { get; set; }

        public string Email { get; set; }

        public string Password { get; set; }
    }
}
