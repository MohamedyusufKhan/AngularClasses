using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using UserService.WebAPI.Models;

namespace UserService.WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]

    public class UsersController : ControllerBase
    {
        [HttpPost]
        public async Task<IActionResult> Validate(User user)
        { 
            return Ok();
        }
    }
}
