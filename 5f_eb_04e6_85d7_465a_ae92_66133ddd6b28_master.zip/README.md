## Environment:
- .NET version: 6.0

## Read-Only Files:
- UserService.Tests/IntegrationTests.cs
- UserService.WebAPI/Controllers/UsersController.cs

## Data:
Example of a user data JSON object:
```
{
   "name": "Alex",
   "email": "alexuser@mail.com",
   "password": "@1!Sdsdw23xzX"
}
```

## Requirements:

A company is launching a service that can validate a user model. The service should be a web API layer using .NET Core 3.0. You already have a prepared infrastructure and need to implement validation logic for the user model as per the guidelines below. Perform validation in models, not in controllers.

Each user data is a JSON object describing the details of the user. Each object has the following properties:

- name: the name of the user. [String]
- email: the email id of the user. [String]
- password: the password of the user. [String]

The following API needs to be implemented:

`POST` request to  `api/users`:

- The HTTP response code should be 200 on success.
- For the body of the request, please use the JSON example of the user model given above.
- If the user model is invalid, return status code 400. When you send 400, add an appropriate error message to the response as described below.

The user model should be validated based on the following rules:

- The name field is required and the minimum length is 2. If the field is invalid, add this error message: `"Name is invalid, must contain a minimum of 2 characters"`.
- The email field is required and must be valid and cannot be empty. Also, the email domain cannot be 'example.com'. A valid email address has 3 parts: recipient name, @ symbol, and domain name. If the field is invalid, add this error message: `"Email is invalid: Email should be valid and cannot contain example.com as domain"`.
- The password field is required and should be at least 6 characters long and should contain at least 1 uppercase, 1 lowercase, and 1 numeric character. If the field is invalid, add this error message: `"Password is invalid: Password must contain 1 small, 1 capital and 1 numeric character"`.
