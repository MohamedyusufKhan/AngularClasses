using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Newtonsoft.Json;
using UserService.WebAPI;
using UserService.WebAPI.SeedData;
using Xunit;

namespace UserService.Tests
{
    public class IntegrationTests : IClassFixture<WebApplicationFactory<Program>>
    {
        private readonly WebApplicationFactory<Program> _factory;

        public HttpClient Client { get; private set; }

        public IntegrationTests(WebApplicationFactory<Program> factory)
        {
            _factory = factory;
            SetUpClient();
        }

        private async Task CheckOnBadRequest(UserForm user, string errorMessage)
        {
            var response0 = await Client.PostAsync($"/api/users",
                new StringContent(JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json"));
            response0.StatusCode.Should().BeEquivalentTo(StatusCodes.Status400BadRequest);
            var responseMessage = await response0.Content.ReadAsStringAsync();
            responseMessage.Contains(errorMessage).Should().BeTrue();
        }

        [Fact]
        // Checking Email
        public async Task TestCases_BadRequests()
        {
            string emailError = "Email is invalid: Email should be valid and cannot contain example.com as domain";
            await CheckOnBadRequest(new UserForm
            {
                Name = "Alex",
                Email = "alexUser.com",
                Password = "@sdas!xXsa4"
            }, emailError);

            await CheckOnBadRequest(new UserForm
            {
                Name = "Alex",
                Email = "",
                Password = "@sdas!xXsa4"
            }, emailError);

            await CheckOnBadRequest(new UserForm
            {
                Name = "Alex",
                Email = "alexUsermail.com",
                Password = "@sdas!xXsa4"
            }, emailError);

            await CheckOnBadRequest(new UserForm
            {
                Name = "Alex",
                Email = "alexUser@example.com",
                Password = "@sdas!xXsa4"
            }, emailError);

            var userWithCorrectData = new UserForm
            {
                Name = "Alex",
                Email = "alexUser@mail.com",
                Password = "@sdas!xXsa4"
            };
            var response3 = await Client.PostAsync($"/api/users",
                new StringContent(JsonConvert.SerializeObject(userWithCorrectData), Encoding.UTF8, "application/json"));
            response3.StatusCode.Should().BeEquivalentTo(StatusCodes.Status200OK);
        }

        [Fact]
        // Checking Password
        public async Task TestCases_BadRequests_Ok()
        {
            string passwordError =
                "Password is invalid: Password must contain 1 small, 1 capital and 1 numeric character";
            await CheckOnBadRequest(new UserForm
            {
                Name = "Alex",
                Email = "alexUser@mail.com",
                Password = "12345"
            }, passwordError);
            await CheckOnBadRequest(new UserForm
            {
                Name = "Alex",
                Email = "alexUser@mail.com",
                Password = "12345asdasdasd"
            }, passwordError);
            await CheckOnBadRequest(new UserForm
            {
                Name = "Alex",
                Email = "alexUser@mail.com",
                Password = "sda213123sasdasdasd"
            }, passwordError);

            var userWithCorrectData = new UserForm
            {
                Name = "Alex",
                Email = "alexUser@mail.com",
                Password = "AsdasxxXsa4"
            };
            var response3 = await Client.PostAsync($"/api/users",
                new StringContent(JsonConvert.SerializeObject(userWithCorrectData), Encoding.UTF8, "application/json"));
            response3.StatusCode.Should().BeEquivalentTo(StatusCodes.Status200OK);
        }

        [Fact]
        // Checking Name
        public async Task TestCases_BadRequest_Ok()
        {
            string nameError = "Name is invalid, must contain a minimum of 2 characters";
            await CheckOnBadRequest(new UserForm
            {
                Name = "D",
                Email = "alexUser@mail.com",
                Password = "@sdas!xXsa4"
            }, nameError);
            await CheckOnBadRequest(new UserForm
            {
                Name = "",
                Email = "alexUser@mail.com",
                Password = "@sdas!xXsa4"
            }, nameError);

            var userWithCorrectData = new UserForm
            {
                Name = "Alex",
                Email = "alexUser@mail.com",
                Password = "@sdas!xXsa4"
            };
            var response3 = await Client.PostAsync($"/api/users",
                new StringContent(JsonConvert.SerializeObject(userWithCorrectData), Encoding.UTF8, "application/json"));
            response3.StatusCode.Should().BeEquivalentTo(StatusCodes.Status200OK);
        }

        private void SetUpClient()
        {
            Client = _factory.WithWebHostBuilder(builder =>
               builder.UseStartup<Startup>()
                .ConfigureServices(services =>
                {

                })).CreateClient();
        }
    }
}
